package com.example.lista1

import java.util.jar.Attributes

class Person(var Name: String, var Age: Int) {

}